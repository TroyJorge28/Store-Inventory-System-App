/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.9.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QGridLayout *gridLayout;
    QLineEdit *idInput;
    QLabel *ID;
    QLineEdit *nameInput;
    QLabel *Name;
    QLineEdit *priceInput;
    QLabel *Price;
    QLineEdit *quantityInput;
    QLabel *Quantity;
    QLineEdit *categoryInput;
    QLabel *Category;
    QHBoxLayout *horizontalLayout;
    QPushButton *updateButton;
    QPushButton *addButton;
    QPushButton *removeButton;
    QPushButton *searchButton;
    QPushButton *saveButton;
    QPushButton *loadButton;
    QTableWidget *InventoryTable;
    QTextEdit *statusOutput;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1272, 683);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        verticalLayout = new QVBoxLayout(centralwidget);
        verticalLayout->setObjectName("verticalLayout");
        gridLayout = new QGridLayout();
        gridLayout->setObjectName("gridLayout");
        idInput = new QLineEdit(centralwidget);
        idInput->setObjectName("idInput");

        gridLayout->addWidget(idInput, 0, 0, 1, 1);

        ID = new QLabel(centralwidget);
        ID->setObjectName("ID");

        gridLayout->addWidget(ID, 1, 0, 1, 1);

        nameInput = new QLineEdit(centralwidget);
        nameInput->setObjectName("nameInput");

        gridLayout->addWidget(nameInput, 2, 0, 1, 1);

        Name = new QLabel(centralwidget);
        Name->setObjectName("Name");

        gridLayout->addWidget(Name, 3, 0, 1, 1);

        priceInput = new QLineEdit(centralwidget);
        priceInput->setObjectName("priceInput");

        gridLayout->addWidget(priceInput, 4, 0, 1, 1);

        Price = new QLabel(centralwidget);
        Price->setObjectName("Price");

        gridLayout->addWidget(Price, 5, 0, 1, 1);

        quantityInput = new QLineEdit(centralwidget);
        quantityInput->setObjectName("quantityInput");

        gridLayout->addWidget(quantityInput, 6, 0, 1, 1);

        Quantity = new QLabel(centralwidget);
        Quantity->setObjectName("Quantity");

        gridLayout->addWidget(Quantity, 7, 0, 1, 1);

        categoryInput = new QLineEdit(centralwidget);
        categoryInput->setObjectName("categoryInput");

        gridLayout->addWidget(categoryInput, 8, 0, 1, 1);

        Category = new QLabel(centralwidget);
        Category->setObjectName("Category");

        gridLayout->addWidget(Category, 9, 0, 1, 1);


        verticalLayout->addLayout(gridLayout);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName("horizontalLayout");
        updateButton = new QPushButton(centralwidget);
        updateButton->setObjectName("updateButton");

        horizontalLayout->addWidget(updateButton);

        addButton = new QPushButton(centralwidget);
        addButton->setObjectName("addButton");

        horizontalLayout->addWidget(addButton);

        removeButton = new QPushButton(centralwidget);
        removeButton->setObjectName("removeButton");

        horizontalLayout->addWidget(removeButton);

        searchButton = new QPushButton(centralwidget);
        searchButton->setObjectName("searchButton");

        horizontalLayout->addWidget(searchButton);

        saveButton = new QPushButton(centralwidget);
        saveButton->setObjectName("saveButton");

        horizontalLayout->addWidget(saveButton);

        loadButton = new QPushButton(centralwidget);
        loadButton->setObjectName("loadButton");

        horizontalLayout->addWidget(loadButton);


        verticalLayout->addLayout(horizontalLayout);

        InventoryTable = new QTableWidget(centralwidget);
        if (InventoryTable->columnCount() < 5)
            InventoryTable->setColumnCount(5);
        InventoryTable->setObjectName("InventoryTable");
        InventoryTable->setEditTriggers(QAbstractItemView::EditTrigger::NoEditTriggers);
        InventoryTable->setSelectionBehavior(QAbstractItemView::SelectionBehavior::SelectRows);
        InventoryTable->setColumnCount(5);
        InventoryTable->horizontalHeader()->setProperty("showSortIndicator", QVariant(false));

        verticalLayout->addWidget(InventoryTable);

        statusOutput = new QTextEdit(centralwidget);
        statusOutput->setObjectName("statusOutput");
        statusOutput->setReadOnly(true);

        verticalLayout->addWidget(statusOutput);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1272, 25));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "Store Inventory System", nullptr));
        idInput->setText(QString());
        idInput->setPlaceholderText(QCoreApplication::translate("MainWindow", "Enter ID", nullptr));
        ID->setText(QCoreApplication::translate("MainWindow", "ID", nullptr));
        nameInput->setText(QString());
        nameInput->setPlaceholderText(QCoreApplication::translate("MainWindow", "Enter Name", nullptr));
        Name->setText(QCoreApplication::translate("MainWindow", "Name", nullptr));
        priceInput->setText(QString());
        priceInput->setPlaceholderText(QCoreApplication::translate("MainWindow", "Enter Price", nullptr));
        Price->setText(QCoreApplication::translate("MainWindow", "Price", nullptr));
        quantityInput->setText(QString());
        quantityInput->setPlaceholderText(QCoreApplication::translate("MainWindow", "Enter Quantity", nullptr));
        Quantity->setText(QCoreApplication::translate("MainWindow", "Quantity", nullptr));
        categoryInput->setText(QString());
        categoryInput->setPlaceholderText(QCoreApplication::translate("MainWindow", "Enter Category", nullptr));
        Category->setText(QCoreApplication::translate("MainWindow", "Category", nullptr));
        updateButton->setText(QCoreApplication::translate("MainWindow", "Update Quantity", nullptr));
        addButton->setText(QCoreApplication::translate("MainWindow", "Add Item", nullptr));
        removeButton->setText(QCoreApplication::translate("MainWindow", "Remove Item", nullptr));
        searchButton->setText(QCoreApplication::translate("MainWindow", "Search Item", nullptr));
        saveButton->setText(QCoreApplication::translate("MainWindow", "Save to File", nullptr));
        loadButton->setText(QCoreApplication::translate("MainWindow", "Load from File", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
