#ifndef ITEM_H
#define ITEM_H
#include "Product.h"

class Item : public Product {
private:
    int quantity;
    char* category;

public:
    Item(int id, const char* name, double price, int qty, const char* cat);
    ~Item();
    void displayDetails() const override;
    void updateQuantity(int qty);
    int getQuantity() const;
    const char* getCategory() const;
};

#endif
