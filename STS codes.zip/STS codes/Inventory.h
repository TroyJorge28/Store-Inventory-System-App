#ifndef INVENTORY_H
#define INVENTORY_H
#include "Item.h"

class Inventory {
private:
    Item** items; // Dynamic array of Item pointers
    int capacity;
    int count; // Current number of items

public:
    Inventory(int initialCapacity = 10);
    ~Inventory();
    void addItem(Item* item);
    void removeItem(int id);
    void displayInventory() const;
    Item* searchItem(int id) const;
    void updateItemQuantity(int id, int qty);
    bool saveToFile(const char* filename) const;
    bool loadFromFile(const char* filename);
    int getCount() const { return count; } // For GUI table
    Item* getItem(int index) const { return items[index]; } // For GUI table
};

#endif
