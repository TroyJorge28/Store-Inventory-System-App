#include "Item.h"
#include "Utilities.h"
#include <iostream>

// Constructor
Item::Item(int id, const char* name, double price, int qty, const char* cat)
    : Product(id, name, price), quantity(qty) {
    category = Utilities::strCopy(cat);
}

// Destructor
Item::~Item() {
    delete[] category;
}

// Display item details
void Item::displayDetails() const {
    std::cout << "ID: " << productId << ", Name: " << name
              << ", Price: $" << price << ", Quantity: " << quantity
              << ", Category: " << category << std::endl;
}

// Update quantity (e.g., restock or sell)
void Item::updateQuantity(int qty) {
    quantity += qty;
    if (quantity < 0) quantity = 0; // Prevent negative quantity
}

// Getters
int Item::getQuantity() const { return quantity; }
const char* Item::getCategory() const { return category; }
