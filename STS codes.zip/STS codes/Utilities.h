#ifndef UTILITIES_H
#define UTILITIES_H

class Utilities {
public:
    static char* strCopy(const char* src); // Custom string copy
    static void getStringInput(char* buffer, int size);
    static int getIntInput();
    static double getDoubleInput();
    static bool createDirectory(const char* path); // Create directory
    static void printFileError(const char* filename); // Detailed file error
};

#endif
