#include "Product.h"
#include "Utilities.h"

// Constructor
Product::Product(int id, const char* nameStr, double priceVal) : productId(id), price(priceVal) {
    name = Utilities::strCopy(nameStr); // Custom string copy
}

// Destructor
Product::~Product() {
    delete[] name; // Free dynamic memory
}

// Getters
int Product::getId() const { return productId; }
double Product::getPrice() const { return price; }
const char* Product::getName() const { return name; }
