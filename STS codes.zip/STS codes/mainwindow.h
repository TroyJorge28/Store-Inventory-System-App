#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "Inventory.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_addButton_clicked();
    void on_removeButton_clicked();
    void on_searchButton_clicked();
    void on_updateButton_clicked();
    void on_saveButton_clicked();
    void on_loadButton_clicked();



    void on_Add_cursorPositionChanged(int arg1, int arg2);

    void on_Remove_cursorPositionChanged(int arg1, int arg2);

    void on_Search_cursorPositionChanged(int arg1, int arg2);

    void on_Update_cursorPositionChanged(int arg1, int arg2);

    void on_Save_cursorPositionChanged(int arg1, int arg2);

    void on_Load_cursorPositionChanged(int arg1, int arg2);



private:
    Ui::MainWindow *ui;
    Inventory *inventory; // Manages the inventory
    void updateTable(); // Updates QTableWidget with inventory data
    void clearInputs(); // Clears input fields
};

#endif // MAINWINDOW_H
