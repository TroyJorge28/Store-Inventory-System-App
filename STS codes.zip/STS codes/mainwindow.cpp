#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Utilities.h"
#include <QTableWidgetItem>
#include <QDoubleValidator>
#include <QIntValidator>
#include <QString>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow), inventory(new Inventory(10)) {
    ui->setupUi(this);

    // Safety check for widget existence
    if (!ui->idInput || !ui->priceInput || !ui->quantityInput || !ui->nameInput || !ui->categoryInput ||
        !ui->InventoryTable || !ui->statusOutput || !ui->addButton || !ui->removeButton ||
        !ui->searchButton || !ui->updateButton || !ui->saveButton || !ui->loadButton) {
        qWarning("One or more UI elements not found. Check mainwindow.ui.");
        return;
    }

    // Set validators for numeric input fields
    ui->idInput->setValidator(new QIntValidator(0, 999999, this)); // Positive IDs
    ui->priceInput->setValidator(new QDoubleValidator(0.0, 1000000.0, 2, this));
    ui->quantityInput->setValidator(new QIntValidator(0, 999999, this)); // Non-negative quantities

    // Initialize table with headers
    ui->InventoryTable->setColumnCount(5);
    QStringList headers = {"ID", "Name", "Price", "Quantity", "Category"};
    ui->InventoryTable->setHorizontalHeaderLabels(headers);
    ui->InventoryTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->statusOutput->setReadOnly(true);
}

MainWindow::~MainWindow() {
    delete inventory;
    delete ui;
}

void MainWindow::updateTable() {
    if (!ui->InventoryTable) return; // Safety check
    ui->InventoryTable->setRowCount(0); // Clear table
    for (int i = 0; i < inventory->getCount(); i++) {
        Item* item = inventory->getItem(i);
        if (item) {
            int row = ui->InventoryTable->rowCount();
            ui->InventoryTable->insertRow(row);
            ui->InventoryTable->setItem(row, 0, new QTableWidgetItem(QString::number(item->getId())));
            ui->InventoryTable->setItem(row, 1, new QTableWidgetItem(item->getName()));
            ui->InventoryTable->setItem(row, 2, new QTableWidgetItem(QString::number(item->getPrice(), 'f', 2)));
            ui->InventoryTable->setItem(row, 3, new QTableWidgetItem(QString::number(item->getQuantity())));
            ui->InventoryTable->setItem(row, 4, new QTableWidgetItem(item->getCategory()));
        }
    }
}

void MainWindow::clearInputs() {
    if (!ui->idInput || !ui->nameInput || !ui->priceInput || !ui->quantityInput || !ui->categoryInput) return;
    ui->idInput->clear();
    ui->nameInput->clear();
    ui->priceInput->clear();
    ui->quantityInput->clear();
    ui->categoryInput->clear();
}

void MainWindow::on_addButton_clicked() {
    if (!ui->idInput || !ui->nameInput || !ui->priceInput || !ui->quantityInput || !ui->categoryInput || !ui->statusOutput) {
        ui->statusOutput->setText("UI initialization error.");
        return;
    }
    if (ui->idInput->text().isEmpty() || ui->nameInput->text().isEmpty() ||
        ui->priceInput->text().isEmpty() || ui->quantityInput->text().isEmpty() ||
        ui->categoryInput->text().isEmpty()) {
        ui->statusOutput->setText("Please fill all fields.");
        return;
    }

    bool ok;
    int id = ui->idInput->text().toInt(&ok);
    if (!ok || id < 0) {
        ui->statusOutput->setText("Invalid ID. Use a positive number.");
        return;
    }
    double price = ui->priceInput->text().toDouble(&ok);
    if (!ok || price < 0.0) {
        ui->statusOutput->setText("Invalid price. Use a positive number.");
        return;
    }
    int quantity = ui->quantityInput->text().toInt(&ok);
    if (!ok || quantity < 0) {
        ui->statusOutput->setText("Invalid quantity. Use a positive number.");
        return;
    }
    QString name = ui->nameInput->text().trimmed();
    QString category = ui->categoryInput->text().trimmed();
    if (name.isEmpty() || category.isEmpty()) {
        ui->statusOutput->setText("Name and category cannot be empty.");
        return;
    }

    Item* item = new Item(id, name.toUtf8().constData(), price, quantity, category.toUtf8().constData());
    inventory->addItem(item);

    updateTable();
    clearInputs();
    ui->statusOutput->setText("Item added successfully.");
}

void MainWindow::on_removeButton_clicked() {
    if (!ui->idInput || !ui->statusOutput) {
        ui->statusOutput->setText("UI initialization error.");
        return;
    }
    if (ui->idInput->text().isEmpty()) {
        ui->statusOutput->setText("Please enter an ID.");
        return;
    }
    bool ok;
    int id = ui->idInput->text().toInt(&ok);
    if (!ok || id < 0) {
        ui->statusOutput->setText("Invalid ID. Use a positive number.");
        return;
    }
    Item* item = inventory->searchItem(id);
    if (!item) {
        ui->statusOutput->setText("Item not found.");
        return;
    }
    inventory->removeItem(id);
    updateTable();
    clearInputs();
    ui->statusOutput->setText("Item removed successfully.");
}

void MainWindow::on_searchButton_clicked() {
    if (!ui->idInput || !ui->nameInput || !ui->priceInput || !ui->quantityInput || !ui->categoryInput || !ui->statusOutput) {
        ui->statusOutput->setText("UI initialization error.");
        return;
    }
    if (ui->idInput->text().isEmpty()) {
        ui->statusOutput->setText("Please enter an ID.");
        return;
    }
    bool ok;
    int id = ui->idInput->text().toInt(&ok);
    if (!ok || id < 0) {
        ui->statusOutput->setText("Invalid ID. Use a positive number.");
        return;
    }
    Item* item = inventory->searchItem(id);
    if (item) {
        ui->nameInput->setText(item->getName());
        ui->priceInput->setText(QString::number(item->getPrice(), 'f', 2));
        ui->quantityInput->setText(QString::number(item->getQuantity()));
        ui->categoryInput->setText(item->getCategory());
        ui->statusOutput->setText("Item found.");
    } else {
        ui->statusOutput->setText("Item not found.");
        clearInputs();
    }
}

void MainWindow::on_updateButton_clicked() {
    if (!ui->idInput || !ui->quantityInput || !ui->statusOutput) {
        ui->statusOutput->setText("UI initialization error.");
        return;
    }
    if (ui->idInput->text().isEmpty() || ui->quantityInput->text().isEmpty()) {
        ui->statusOutput->setText("Please enter ID and quantity.");
        return;
    }
    bool ok;
    int id = ui->idInput->text().toInt(&ok);
    if (!ok || id < 0) {
        ui->statusOutput->setText("Invalid ID. Use a positive number.");
        return;
    }
    int qty = ui->quantityInput->text().toInt(&ok);
    if (!ok || qty < 0) {
        ui->statusOutput->setText("Invalid quantity. Use a positive number.");
        return;
    }
    Item* item = inventory->searchItem(id);
    if (!item) {
        ui->statusOutput->setText("Item not found.");
        return;
    }
    inventory->updateItemQuantity(id, qty);
    updateTable();
    clearInputs();
    ui->statusOutput->setText("Quantity updated successfully.");
}

void MainWindow::on_saveButton_clicked() {
    if (!ui->statusOutput) {
        qWarning("Status output not found.");
        return;
    }
    if (!Utilities::createDirectory("data")) {
        ui->statusOutput->setText("Failed to create data directory.");
        return;
    }
    if (inventory->getCount() == 0) {
        ui->statusOutput->setText("Inventory is empty. Nothing to save.");
        return;
    }
    if (inventory->saveToFile("data/inventory.txt")) {
        ui->statusOutput->setText("Inventory saved successfully.");
    } else {
        ui->statusOutput->setText("Failed to save inventory.");
    }
}

void MainWindow::on_loadButton_clicked() {
    if (!ui->statusOutput) {
        qWarning("Status output not found.");
        return;
    }
    if (inventory->loadFromFile("data/inventory.txt")) {
        updateTable();
        ui->statusOutput->setText("Inventory loaded successfully.");
    } else {
        ui->statusOutput->setText("Failed to load inventory.");
    }
}


// Dummy slot definitions to fix linker errors for cursorPositionChanged signals

void MainWindow::on_Add_cursorPositionChanged(int, int) {
    // No action needed
}

void MainWindow::on_Remove_cursorPositionChanged(int, int) {
    // No action needed
}

void MainWindow::on_Search_cursorPositionChanged(int, int) {
    // No action needed
}

void MainWindow::on_Update_cursorPositionChanged(int, int) {
    // No action needed
}

void MainWindow::on_Save_cursorPositionChanged(int, int) {
    // No action needed
}

void MainWindow::on_Load_cursorPositionChanged(int, int) {
    // No action needed
}
