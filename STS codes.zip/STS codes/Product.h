#ifndef PRODUCT_H
#define PRODUCT_H

class Product {
protected:
    int productId;
    char* name; // Dynamic array for name
    double price;

public:
    Product(int id, const char* name, double price);
    virtual ~Product(); // Virtual destructor for proper cleanup
    virtual void displayDetails() const = 0; // Pure virtual function
    int getId() const;
    double getPrice() const;
    const char* getName() const;
};

#endif
