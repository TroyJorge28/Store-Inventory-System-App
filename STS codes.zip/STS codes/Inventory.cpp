#include "Inventory.h"
#include "Utilities.h"
#include <iostream>
#include <fstream>

// Constructor
Inventory::Inventory(int initialCapacity) : capacity(initialCapacity), count(0) {
    items = new Item*[capacity];
    for (int i = 0; i < capacity; i++) {
        items[i] = nullptr;
    }
}

// Destructor
Inventory::~Inventory() {
    for (int i = 0; i < count; i++) {
        delete items[i];
    }
    delete[] items;
}

// Add item to inventory
void Inventory::addItem(Item* item) {
    if (count >= capacity) {
        // Resize array
        Item** newItems = new Item*[capacity * 2];
        for (int i = 0; i < count; i++) {
            newItems[i] = items[i];
        }
        delete[] items;
        items = newItems;
        capacity *= 2;
    }
    items[count++] = item;
}

// Remove item by ID
void Inventory::removeItem(int id) {
    for (int i = 0; i < count; i++) {
        if (items[i] && items[i]->getId() == id) {
            delete items[i];
            items[i] = items[count - 1]; // Move last item to fill gap
            items[count - 1] = nullptr;
            count--;
            return;
        }
    }
    std::cout << "Item not found.\n";
}

// Display all items
void Inventory::displayInventory() const {
    if (count == 0) {
        std::cout << "Inventory is empty.\n";
        return;
    }
    for (int i = 0; i < count; i++) {
        if (items[i]) {
            items[i]->displayDetails();
        }
    }
}

// Search item by ID
Item* Inventory::searchItem(int id) const {
    for (int i = 0; i < count; i++) {
        if (items[i] && items[i]->getId() == id) {
            return items[i];
        }
    }
    return nullptr;
}

// Update item quantity
void Inventory::updateItemQuantity(int id, int qty) {
    Item* item = searchItem(id);
    if (item) {
        item->updateQuantity(qty);
    } else {
        std::cout << "Item not found.\n";
    }
}

// Save inventory to file
bool Inventory::saveToFile(const char* filename) const {
    if (count == 0) { // Check if inventory is empty
        std::cout << "Inventory is empty. Nothing to save.\n";
        return false; // Prevent file modification
    }
    std::ofstream outFile(filename);
    if (!outFile) {
        Utilities::printFileError(filename); // Detailed error message
        return false;
    }
    for (int i = 0; i < count; i++) {
        if (items[i]) {
            outFile << items[i]->getId() << " "
                    << items[i]->getName() << " "
                    << items[i]->getPrice() << " "
                    << items[i]->getQuantity() << " "
                    << items[i]->getCategory() << "\n";
        }
    }
    outFile.close();
    return true;
}

// Load inventory from file
bool Inventory::loadFromFile(const char* filename) {
    std::ifstream inFile(filename);
    if (!inFile) {
        Utilities::printFileError(filename);
        return false;
    }
    int id, quantity;
    double price;
    char name[100], category[100];
    while (inFile >> id >> name >> price >> quantity >> category) {
        Item* item = new Item(id, name, price, quantity, category);
        addItem(item);
    }
    inFile.close();
    return true;
}
