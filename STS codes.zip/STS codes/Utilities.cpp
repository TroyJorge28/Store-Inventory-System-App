#include "Utilities.h"
#include <iostream>
#include <cerrno>
#include <cstring>
#ifdef _WIN32
#include <direct.h>
#else
#include <sys/stat.h>
#include <sys/types.h>
#endif

char* Utilities::strCopy(const char* src) {
    int len = 0;
    while (src[len]) len++;
    char* dest = new char[len + 1];
    for (int i = 0; i <= len; i++) {
        dest[i] = src[i];
    }
    return dest;
}

void Utilities::getStringInput(char* buffer, int size) {
    std::cin.getline(buffer, size);
}

int Utilities::getIntInput() {
    int value;
    while (!(std::cin >> value)) {
        std::cout << "Invalid input. Enter a number: ";
        std::cin.clear();
        std::cin.ignore(10000, '\n');
    }
    std::cin.ignore(10000, '\n');
    return value;
}

double Utilities::getDoubleInput() {
    double value;
    while (!(std::cin >> value)) {
        std::cout << "Invalid input. Enter a number: ";
        std::cin.clear();
        std::cin.ignore(10000, '\n');
    }
    std::cin.ignore(10000, '\n');
    return value;
}

bool Utilities::createDirectory(const char* path) {
#ifdef _WIN32
    return _mkdir(path) == 0 || errno == EEXIST;
#else
    return mkdir(path, 0755) == 0 || errno == EEXIST;
#endif
}

void Utilities::printFileError(const char* filename) {
    std::cout << "Error opening file '" << filename << "': " << std::strerror(errno) << "\n";
}
